import tkinter as tk
from tkinter import ttk, messagebox
from database import cek_koneksi
from repository import KaryawanRepository, GajiRepository
from model import rupiah
from views.karyawan import KaryawanView
from views.gaji import GajiView
from views.laporan import LaporanView


class AplikasiPenggajian(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sistem Manajemen Penggajian Karyawan")
        self.geometry("1120x720")
        self.minsize(900,600)
        self.configure(bg="#f4f6f9")
        self.container = ttk.Frame(self)
        self.container.pack(fill="both",expand=True)
        self._style()
        self._menu()
        self.tampilkan_dashboard()

    def _style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TButton",padding=6)
        style.configure("Treeview",rowheight=27)
        style.configure("Treeview.Heading",font=("Segoe UI",9,"bold"))

    def _menu(self):
        menu = tk.Menu(self)
        file_menu = tk.Menu(menu,tearoff=False)
        file_menu.add_command(label="Dashboard",command=self.tampilkan_dashboard)
        file_menu.add_separator()
        file_menu.add_command(label="Keluar",command=self.destroy)
        menu.add_cascade(label="File",menu=file_menu)

        master = tk.Menu(menu,tearoff=False)
        master.add_command(label="Data Karyawan",command=lambda:self.tampilkan(KaryawanView))
        menu.add_cascade(label="Master Data",menu=master)

        transaksi = tk.Menu(menu,tearoff=False)
        transaksi.add_command(label="Penggajian Bulanan",command=lambda:self.tampilkan(GajiView))
        menu.add_cascade(label="Transaksi",menu=transaksi)

        laporan = tk.Menu(menu,tearoff=False)
        laporan.add_command(label="Riwayat dan Ekspor",command=lambda:self.tampilkan(LaporanView))
        menu.add_cascade(label="Laporan",menu=laporan)

        bantuan = tk.Menu(menu,tearoff=False)
        bantuan.add_command(label="Tentang Aplikasi",command=self.tentang)
        bantuan.add_command(label="Status Koneksi Database",command=self.status_db)
        menu.add_cascade(label="Bantuan",menu=bantuan)
        self.config(menu=menu)

    def bersihkan(self):
        for widget in self.container.winfo_children():
            widget.destroy()

    def tampilkan(self, kelas):
        self.bersihkan()
        kelas(self.container).pack(fill="both",expand=True)

    def tampilkan_dashboard(self):
        self.bersihkan()
        frame = ttk.Frame(self.container,padding=22)
        frame.pack(fill="both",expand=True)
        ttk.Label(frame,text="Dashboard",font=("Segoe UI",24,"bold")).pack(anchor="w")
        ttk.Label(frame,text="Ringkasan penggajian periode berjalan",
                  font=("Segoe UI",10)).pack(anchor="w",pady=(2,18))
        grid = ttk.Frame(frame)
        grid.pack(fill="x")
        for i in range(3):
            grid.columnconfigure(i,weight=1)
        try:
            data = GajiRepository().ringkasan()
            kartu = [
                ("Karyawan Aktif",str(data["karyawan_aktif"])),
                ("Transaksi Bulan Ini",str(data["transaksi"])),
                ("Total Gaji Netto",rupiah(data["total_netto"]))
            ]
            status = "Terhubung ke MySQL"
        except Exception as exc:
            kartu = [("Karyawan Aktif","-"),("Transaksi Bulan Ini","-"),("Total Gaji Netto","-")]
            status = f"Database belum tersedia: {exc}"
        for i,(judul,nilai) in enumerate(kartu):
            card = ttk.LabelFrame(grid,text=judul,padding=18)
            card.grid(row=0,column=i,sticky="nsew",padx=6)
            ttk.Label(card,text=nilai,font=("Segoe UI",17,"bold")).pack(anchor="w")
        ttk.Label(frame,text=status,foreground="#287a46" if "Terhubung" in status else "#a33").pack(anchor="w",pady=18)
        tombol = ttk.Frame(frame)
        tombol.pack(anchor="w",pady=8)
        ttk.Button(tombol,text="Kelola Karyawan",command=lambda:self.tampilkan(KaryawanView)).pack(side="left",padx=4)
        ttk.Button(tombol,text="Proses Penggajian",command=lambda:self.tampilkan(GajiView)).pack(side="left",padx=4)
        ttk.Button(tombol,text="Lihat Laporan",command=lambda:self.tampilkan(LaporanView)).pack(side="left",padx=4)

    def status_db(self):
        berhasil, pesan = cek_koneksi()
        if berhasil:
            messagebox.showinfo("Koneksi Database",f"Koneksi berhasil.\nMySQL: {pesan}")
        else:
            messagebox.showerror("Koneksi Database",pesan)

    def tentang(self):
        messagebox.showinfo(
            "Tentang",
            "Sistem Manajemen Penggajian Karyawan\nPython Tkinter + MySQL\n"
            "Contoh proyek pembelajaran implementasi database."
        )


if __name__ == "__main__":
    AplikasiPenggajian().mainloop()
