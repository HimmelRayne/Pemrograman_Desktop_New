from database import cek_koneksi


if __name__ == "__main__":
    berhasil, pesan = cek_koneksi()
    if berhasil:
        print(f"Koneksi berhasil. Versi MySQL: {pesan}")
    else:
        print(f"Koneksi gagal: {pesan}")
