import configparser
from contextlib import contextmanager
from pathlib import Path

import mysql.connector
from mysql.connector import Error


BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.ini"


def baca_konfigurasi():
    parser = configparser.ConfigParser()
    if not CONFIG_PATH.exists():
        raise FileNotFoundError(
            f"File konfigurasi tidak ditemukan: {CONFIG_PATH}. "
            "Salin config.example.ini menjadi config.ini."
        )
    parser.read(CONFIG_PATH, encoding="utf-8")
    if "mysql" not in parser:
        raise ValueError("Bagian [mysql] tidak ditemukan di config.ini.")
    bagian = parser["mysql"]
    return {
        "host": bagian.get("host", "localhost"),
        "port": bagian.getint("port", 3306),
        "user": bagian.get("user", "root"),
        "password": bagian.get("password", ""),
        "database": bagian.get("database", "db_penggajian_modul5"),
        "charset": "utf8mb4",
        "use_unicode": True,
        "autocommit": False,
    }


@contextmanager
def koneksi():
    conn = None
    try:
        conn = mysql.connector.connect(**baca_konfigurasi())
        conn.autocommit = False
        yield conn
        conn.commit()
    except Exception:
        if conn is not None and conn.is_connected():
            conn.rollback()
        raise
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def cek_koneksi():
    try:
        with koneksi() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT VERSION()")
                versi = cursor.fetchone()[0]
        return True, versi
    except (Error, Exception) as exc:
        return False, str(exc)
