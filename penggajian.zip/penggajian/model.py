from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import re


DUA_DESIMAL = Decimal("0.01")


@dataclass(frozen=True)
class Karyawan:
    id: int | None
    nik: str
    nama: str
    jabatan: str
    gaji_pokok: Decimal
    tanggal_masuk: date
    status: str = "Aktif"


def teks(nilai, nama_field, minimum=1, maksimum=120):
    hasil = str(nilai if nilai is not None else "").strip()
    if len(hasil) < minimum:
        raise ValueError(f"{nama_field} wajib diisi.")
    if len(hasil) > maksimum:
        raise ValueError(f"{nama_field} maksimal {maksimum} karakter.")
    if any(ord(ch) < 32 for ch in hasil):
        raise ValueError(f"{nama_field} mengandung karakter yang tidak valid.")
    return hasil


def angka(nilai, nama_field="Angka", minimum=Decimal("0"),
          maksimum=Decimal("999999999999.99")):
    try:
        teks_angka = str(nilai).strip().replace(",", "")
        hasil = Decimal(teks_angka)
    except (InvalidOperation, ValueError, AttributeError):
        raise ValueError(f"{nama_field} harus berupa angka yang valid.")
    if not hasil.is_finite():
        raise ValueError(f"{nama_field} harus berupa angka yang valid.")
    if hasil < minimum:
        raise ValueError(f"{nama_field} minimal {minimum}.")
    if hasil > maksimum:
        raise ValueError(f"{nama_field} maksimal {maksimum}.")
    return hasil.quantize(DUA_DESIMAL, rounding=ROUND_HALF_UP)


def periode_valid(nilai):
    if isinstance(nilai, (date, datetime)):
        return date(nilai.year, nilai.month, 1)
    nilai = str(nilai).strip()
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", nilai):
        raise ValueError("Periode harus menggunakan format YYYY-MM, misalnya 2026-11.")
    tahun, bulan = map(int, nilai.split("-"))
    return date(tahun, bulan, 1)


def rupiah(nilai):
    nilai = Decimal(str(nilai)).quantize(DUA_DESIMAL, rounding=ROUND_HALF_UP)
    angka_bulat = f"{nilai:,.2f}"
    angka_bulat = angka_bulat.replace(",", "_").replace(".", ",").replace("_", ".")
    return f"Rp {angka_bulat}"


def hitung_gaji(gaji_pokok, lembur_jam=0, potongan=0,
                pengali_lembur=Decimal("1.5"), jam_kerja_bulanan=173):
    pokok = angka(gaji_pokok, "Gaji pokok")
    jam = angka(lembur_jam, "Lembur", Decimal("0"), Decimal("744"))
    potong = angka(potongan, "Potongan")
    pengali = Decimal(str(pengali_lembur))
    if pengali <= 0 or jam_kerja_bulanan <= 0:
        raise ValueError("Parameter lembur tidak valid.")
    upah_per_jam = pokok / Decimal(jam_kerja_bulanan)
    upah_lembur = (upah_per_jam * pengali * jam).quantize(
        DUA_DESIMAL, rounding=ROUND_HALF_UP
    )
    bruto = (pokok + upah_lembur).quantize(DUA_DESIMAL, rounding=ROUND_HALF_UP)
    if potong > bruto:
        raise ValueError("Potongan tidak boleh melebihi gaji bruto.")
    netto = (bruto - potong).quantize(DUA_DESIMAL, rounding=ROUND_HALF_UP)
    return {
        "gaji_pokok": pokok,
        "lembur_jam": jam,
        "upah_lembur": upah_lembur,
        "bruto": bruto,
        "potongan": potong,
        "netto": netto,
    }
