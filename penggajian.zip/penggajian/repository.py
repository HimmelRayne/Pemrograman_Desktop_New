from mysql.connector import IntegrityError
from database import koneksi
from model import Karyawan, angka, teks, periode_valid, hitung_gaji


class KaryawanRepository:
    def semua(self, kata_kunci=""):
        sql = """
            SELECT id, nik, nama, jabatan, gaji_pokok, tanggal_masuk, status
            FROM karyawan
            WHERE nik LIKE %s OR nama LIKE %s OR jabatan LIKE %s
            ORDER BY nama
        """
        pola = f"%{kata_kunci.strip()}%"
        with koneksi() as conn:
            with conn.cursor(dictionary=True) as cur:
                cur.execute(sql, (pola, pola, pola))
                return cur.fetchall()

    def aktif(self):
        with koneksi() as conn:
            with conn.cursor(dictionary=True) as cur:
                cur.execute("""
                    SELECT id, nik, nama, jabatan, gaji_pokok, tanggal_masuk, status
                    FROM karyawan WHERE status='Aktif' ORDER BY nama
                """)
                return cur.fetchall()

    def ambil(self, karyawan_id):
        with koneksi() as conn:
            with conn.cursor(dictionary=True) as cur:
                cur.execute("SELECT * FROM karyawan WHERE id=%s", (karyawan_id,))
                return cur.fetchone()

    def tambah(self, data):
        nik = teks(data["nik"], "NIK", 1, 30)
        nama = teks(data["nama"], "Nama", 1, 120)
        jabatan = teks(data["jabatan"], "Jabatan", 1, 100)
        gaji = angka(data["gaji_pokok"], "Gaji pokok")
        tanggal = data["tanggal_masuk"]
        status = data.get("status", "Aktif")
        if status not in ("Aktif", "Nonaktif"):
            raise ValueError("Status karyawan tidak valid.")
        try:
            with koneksi() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        INSERT INTO karyawan
                        (nik,nama,jabatan,gaji_pokok,tanggal_masuk,status)
                        VALUES (%s,%s,%s,%s,%s,%s)
                    """, (nik, nama, jabatan, gaji, tanggal, status))
                    return cur.lastrowid
        except IntegrityError as exc:
            raise ValueError("NIK sudah digunakan atau data melanggar aturan database.") from exc

    def ubah(self, karyawan_id, data):
        nik = teks(data["nik"], "NIK", 1, 30)
        nama = teks(data["nama"], "Nama", 1, 120)
        jabatan = teks(data["jabatan"], "Jabatan", 1, 100)
        gaji = angka(data["gaji_pokok"], "Gaji pokok")
        status = data.get("status", "Aktif")
        try:
            with koneksi() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        UPDATE karyawan SET nik=%s,nama=%s,jabatan=%s,
                        gaji_pokok=%s,tanggal_masuk=%s,status=%s WHERE id=%s
                    """, (nik, nama, jabatan, gaji, data["tanggal_masuk"],
                          status, karyawan_id))
                    if cur.rowcount == 0:
                        raise ValueError("Data karyawan tidak ditemukan.")
        except IntegrityError as exc:
            raise ValueError("NIK sudah digunakan atau data melanggar aturan database.") from exc

    def hapus(self, karyawan_id):
        try:
            with koneksi() as conn:
                with conn.cursor() as cur:
                    cur.execute("DELETE FROM karyawan WHERE id=%s", (karyawan_id,))
                    if cur.rowcount == 0:
                        raise ValueError("Data karyawan tidak ditemukan.")
        except IntegrityError as exc:
            raise ValueError(
                "Karyawan tidak dapat dihapus karena sudah memiliki riwayat penggajian."
            ) from exc


class GajiRepository:
    def simpan(self, karyawan, periode, lembur_jam, potongan, catatan=""):
        periode_db = periode_valid(periode)
        hasil = hitung_gaji(karyawan["gaji_pokok"], lembur_jam, potongan)
        try:
            with koneksi() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        INSERT INTO penggajian
                        (karyawan_id,periode,snapshot_nik,snapshot_nama,
                         snapshot_jabatan,snapshot_gaji_pokok,lembur_jam,
                         upah_lembur,bruto,potongan,netto,catatan)
                        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    """, (
                        karyawan["id"], periode_db, karyawan["nik"],
                        karyawan["nama"], karyawan["jabatan"],
                        hasil["gaji_pokok"], hasil["lembur_jam"],
                        hasil["upah_lembur"], hasil["bruto"],
                        hasil["potongan"], hasil["netto"],
                        teks(catatan, "Catatan", 0, 255) if catatan else None
                    ))
                    return cur.lastrowid, hasil
        except IntegrityError as exc:
            raise ValueError(
                "Gaji untuk karyawan tersebut pada periode ini sudah tersimpan."
            ) from exc

    def riwayat(self, periode=""):
        sql = """
            SELECT id,karyawan_id,periode,snapshot_nik,snapshot_nama,
                   snapshot_jabatan,snapshot_gaji_pokok,lembur_jam,
                   upah_lembur,bruto,potongan,netto,catatan,created_at
            FROM penggajian
        """
        params = ()
        if periode.strip():
            sql += " WHERE periode=%s"
            params = (periode_valid(periode),)
        sql += " ORDER BY periode DESC, snapshot_nama"
        with koneksi() as conn:
            with conn.cursor(dictionary=True) as cur:
                cur.execute(sql, params)
                return cur.fetchall()

    def ringkasan(self):
        with koneksi() as conn:
            with conn.cursor(dictionary=True) as cur:
                cur.execute("""
                    SELECT
                      (SELECT COUNT(*) FROM karyawan WHERE status='Aktif') AS karyawan_aktif,
                      COUNT(*) AS transaksi,
                      COALESCE(SUM(netto),0) AS total_netto,
                      COALESCE(SUM(bruto),0) AS total_bruto
                    FROM penggajian
                    WHERE periode = DATE_FORMAT(CURDATE(), '%Y-%m-01')
                """)
                return cur.fetchone()
