CREATE DATABASE IF NOT EXISTS db_penggajian_modul5
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_penggajian_modul5;

CREATE TABLE IF NOT EXISTS karyawan (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nik VARCHAR(30) NOT NULL,
    nama VARCHAR(120) NOT NULL,
    jabatan VARCHAR(100) NOT NULL,
    gaji_pokok DECIMAL(15,2) NOT NULL,
    tanggal_masuk DATE NOT NULL,
    status ENUM('Aktif', 'Nonaktif') NOT NULL DEFAULT 'Aktif',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT uq_karyawan_nik UNIQUE (nik),
    CONSTRAINT chk_karyawan_gaji CHECK (gaji_pokok >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS penggajian (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    karyawan_id BIGINT UNSIGNED NOT NULL,
    periode DATE NOT NULL,
    snapshot_nik VARCHAR(30) NOT NULL,
    snapshot_nama VARCHAR(120) NOT NULL,
    snapshot_jabatan VARCHAR(100) NOT NULL,
    snapshot_gaji_pokok DECIMAL(15,2) NOT NULL,
    lembur_jam DECIMAL(7,2) NOT NULL DEFAULT 0,
    upah_lembur DECIMAL(15,2) NOT NULL DEFAULT 0,
    bruto DECIMAL(15,2) NOT NULL,
    potongan DECIMAL(15,2) NOT NULL DEFAULT 0,
    netto DECIMAL(15,2) NOT NULL,
    catatan VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_penggajian_karyawan
      FOREIGN KEY (karyawan_id) REFERENCES karyawan(id)
      ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT uq_penggajian_karyawan_periode UNIQUE (karyawan_id, periode),
    CONSTRAINT chk_penggajian_nonnegatif CHECK (
      snapshot_gaji_pokok >= 0 AND lembur_jam >= 0 AND upah_lembur >= 0
      AND bruto >= 0 AND potongan >= 0 AND netto >= 0
    ),
    INDEX idx_penggajian_periode (periode),
    INDEX idx_penggajian_nama (snapshot_nama)
) ENGINE=InnoDB;
