import unittest
from decimal import Decimal
from datetime import date
from model import angka, periode_valid, hitung_gaji, rupiah


class TestModelPenggajian(unittest.TestCase):
    def test_hitung_gaji_tanpa_lembur(self):
        hasil = hitung_gaji("5000000", "0", "250000")
        self.assertEqual(hasil["gaji_pokok"], Decimal("5000000.00"))
        self.assertEqual(hasil["upah_lembur"], Decimal("0.00"))
        self.assertEqual(hasil["bruto"], Decimal("5000000.00"))
        self.assertEqual(hasil["netto"], Decimal("4750000.00"))

    def test_hitung_gaji_dengan_lembur(self):
        hasil = hitung_gaji("1730000", "2", "10000")
        self.assertEqual(hasil["upah_lembur"], Decimal("30000.00"))
        self.assertEqual(hasil["bruto"], Decimal("1760000.00"))
        self.assertEqual(hasil["netto"], Decimal("1750000.00"))

    def test_potongan_melebihi_bruto(self):
        with self.assertRaises(ValueError):
            hitung_gaji("1000000", "0", "1000001")

    def test_validasi_angka(self):
        self.assertEqual(angka("1234.5"), Decimal("1234.50"))
        with self.assertRaises(ValueError):
            angka("bukan angka")
        with self.assertRaises(ValueError):
            angka("-10")

    def test_periode_valid(self):
        self.assertEqual(periode_valid("2026-11"), date(2026,11,1))
        with self.assertRaises(ValueError):
            periode_valid("11-2026")
        with self.assertRaises(ValueError):
            periode_valid("2026-13")

    def test_format_rupiah(self):
        self.assertEqual(rupiah("1500000"), "Rp 1.500.000,00")


if __name__ == "__main__":
    unittest.main()
