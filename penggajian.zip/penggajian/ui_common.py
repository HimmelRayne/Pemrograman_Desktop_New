import logging
from functools import wraps
from tkinter import messagebox, ttk


logging.basicConfig(
    filename="penggajian.log",
    level=logging.ERROR,
    format="%(asctime)s %(levelname)s %(message)s",
    encoding="utf-8"
)


def aman(judul="Terjadi Kesalahan"):
    def dekorator(fungsi):
        @wraps(fungsi)
        def pembungkus(*args, **kwargs):
            try:
                return fungsi(*args, **kwargs)
            except Exception as exc:
                logging.exception("Kesalahan pada %s", fungsi.__name__)
                messagebox.showerror(judul, str(exc))
                return None
        return pembungkus
    return dekorator


def tabel(parent, kolom, judul=None, tinggi=12):
    frame = ttk.Frame(parent)
    frame.pack(fill="both", expand=True)
    tree = ttk.Treeview(frame, columns=kolom, show="headings", height=tinggi)
    for kol in kolom:
        tree.heading(kol, text=(judul or {}).get(kol, kol.replace("_", " ").title()))
        tree.column(kol, width=125, anchor="w")
    scroll_y = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    scroll_x = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
    tree.grid(row=0, column=0, sticky="nsew")
    scroll_y.grid(row=0, column=1, sticky="ns")
    scroll_x.grid(row=1, column=0, sticky="ew")
    frame.rowconfigure(0, weight=1)
    frame.columnconfigure(0, weight=1)
    return tree


def input_teks(parent, label, variabel, baris, lebar=28):
    from tkinter import ttk
    ttk.Label(parent, text=label).grid(row=baris, column=0, sticky="w", padx=6, pady=5)
    entri = ttk.Entry(parent, textvariable=variabel, width=lebar)
    entri.grid(row=baris, column=1, sticky="ew", padx=6, pady=5)
    return entri
