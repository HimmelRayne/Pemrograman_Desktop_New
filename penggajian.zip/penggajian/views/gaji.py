import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
from decimal import Decimal
from repository import KaryawanRepository, GajiRepository
from model import hitung_gaji, rupiah
from ui_common import aman


class GajiView(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=16)
        self.karyawan_repo = KaryawanRepository()
        self.gaji_repo = GajiRepository()
        self.karyawan = []
        self.pilihan = tk.StringVar()
        self.periode = tk.StringVar(value=date.today().strftime("%Y-%m"))
        self.lembur = tk.StringVar(value="0")
        self.potongan = tk.StringVar(value="0")
        self.catatan = tk.StringVar()
        ttk.Label(self, text="Transaksi Penggajian", font=("Segoe UI",18,"bold")).pack(anchor="w", pady=(0,12))
        form = ttk.LabelFrame(self, text="Input Penggajian", padding=12)
        form.pack(fill="x")
        self.combo = ttk.Combobox(form, textvariable=self.pilihan, state="readonly", width=42)
        self._field(form, "Karyawan Aktif", self.combo, 0)
        self._field(form, "Periode (YYYY-MM)", ttk.Entry(form, textvariable=self.periode, width=45), 1)
        self._field(form, "Lembur (jam)", ttk.Entry(form, textvariable=self.lembur, width=45), 2)
        self._field(form, "Potongan (Rp)", ttk.Entry(form, textvariable=self.potongan, width=45), 3)
        self._field(form, "Catatan", ttk.Entry(form, textvariable=self.catatan, width=45), 4)
        ttk.Button(form, text="Pratinjau Hitungan", command=self.pratinjau).grid(row=5,column=1,sticky="w",padx=6,pady=8)
        self.preview = tk.StringVar(value="Pilih karyawan dan isi komponen gaji.")
        ttk.Label(self, textvariable=self.preview, justify="left", font=("Segoe UI",11)).pack(anchor="w", pady=16)
        ttk.Button(self, text="Simpan Penggajian", command=self.simpan).pack(anchor="w")
        self.muat_karyawan()

    def _field(self, parent, label, widget, row):
        ttk.Label(parent,text=label).grid(row=row,column=0,sticky="w",padx=6,pady=5)
        widget.grid(row=row,column=1,sticky="w",padx=6,pady=5)

    @aman("Gagal Memuat Karyawan")
    def muat_karyawan(self):
        self.karyawan = self.karyawan_repo.aktif()
        self.pilihan.set("")
        self.combo["values"] = [
            f'{k["id"]} | {k["nik"]} | {k["nama"]}' for k in self.karyawan
        ]

    def karyawan_terpilih(self):
        nilai = self.pilihan.get()
        if not nilai:
            raise ValueError("Pilih karyawan terlebih dahulu.")
        identitas = int(nilai.split("|")[0].strip())
        return next(k for k in self.karyawan if k["id"] == identitas)

    @aman("Pratinjau Gagal")
    def pratinjau(self):
        k = self.karyawan_terpilih()
        hasil = hitung_gaji(k["gaji_pokok"], self.lembur.get(), self.potongan.get())
        self.preview.set(
            f'Karyawan: {k["nama"]}\n'
            f'Gaji pokok: {rupiah(hasil["gaji_pokok"])}\n'
            f'Upah lembur: {rupiah(hasil["upah_lembur"])}\n'
            f'Gaji bruto: {rupiah(hasil["bruto"])}\n'
            f'Potongan: {rupiah(hasil["potongan"])}\n'
            f'Gaji netto: {rupiah(hasil["netto"])}'
        )

    @aman("Gagal Menyimpan Penggajian")
    def simpan(self):
        k = self.karyawan_terpilih()
        identitas, hasil = self.gaji_repo.simpan(
            k, self.periode.get(), self.lembur.get(),
            self.potongan.get(), self.catatan.get()
        )
        messagebox.showinfo("Berhasil", f"Transaksi gaji tersimpan dengan ID {identitas}.\nNetto: {rupiah(hasil['netto'])}")
        self.lembur.set("0")
        self.potongan.set("0")
        self.catatan.set("")
        self.preview.set("Transaksi berhasil disimpan.")
