import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
from repository import KaryawanRepository
from ui_common import tabel, aman


class KaryawanView(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=12)
        self.repo = KaryawanRepository()
        self.columnconfigure(0, weight=1)
        ttk.Label(self, text="Data Karyawan", font=("Segoe UI", 18, "bold")).pack(anchor="w", pady=(0, 10))
        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=5)
        self.cari = tk.StringVar()
        ttk.Label(bar, text="Cari NIK/Nama/Jabatan:").pack(side="left")
        ent = ttk.Entry(bar, textvariable=self.cari, width=30)
        ent.pack(side="left", padx=6)
        ent.bind("<Return>", lambda e: self.muat())
        ttk.Button(bar, text="Cari", command=self.muat).pack(side="left")
        ttk.Button(bar, text="Tambah Karyawan", command=self.form_tambah).pack(side="right")
        self.tree = tabel(self, ("id","nik","nama","jabatan","gaji_pokok","tanggal_masuk","status"),
                          {"id":"ID","gaji_pokok":"Gaji Pokok","tanggal_masuk":"Tanggal Masuk"})
        aksi = ttk.Frame(self)
        aksi.pack(fill="x", pady=8)
        ttk.Button(aksi, text="Edit", command=self.form_edit).pack(side="left", padx=3)
        ttk.Button(aksi, text="Hapus", command=self.hapus).pack(side="left", padx=3)
        self.muat()

    @aman("Gagal Memuat Karyawan")
    def muat(self):
        self.tree.delete(*self.tree.get_children())
        for row in self.repo.semua(self.cari.get()):
            self.tree.insert("", "end", values=(
                row["id"], row["nik"], row["nama"], row["jabatan"],
                row["gaji_pokok"], row["tanggal_masuk"], row["status"]
            ))

    def form_tambah(self):
        self._form()

    def form_edit(self):
        pilihan = self.tree.selection()
        if not pilihan:
            messagebox.showwarning("Pilih Data", "Pilih karyawan yang akan diedit.")
            return
        nilai = self.tree.item(pilihan[0], "values")
        data = self.repo.ambil(int(nilai[0]))
        self._form(data)

    def _form(self, data=None):
        edit = data is not None
        win = tk.Toplevel(self)
        win.title("Edit Karyawan" if edit else "Tambah Karyawan")
        win.transient(self.winfo_toplevel())
        win.grab_set()
        frame = ttk.Frame(win, padding=16)
        frame.pack(fill="both", expand=True)
        fields = {}
        defaults = {
            "NIK": data["nik"] if edit else "",
            "Nama": data["nama"] if edit else "",
            "Jabatan": data["jabatan"] if edit else "",
            "Gaji Pokok": str(data["gaji_pokok"]) if edit else "",
            "Tanggal Masuk (YYYY-MM-DD)": str(data["tanggal_masuk"]) if edit else str(date.today()),
        }
        for i, (label, value) in enumerate(defaults.items()):
            ttk.Label(frame, text=label).grid(row=i, column=0, sticky="w", pady=5, padx=5)
            var = tk.StringVar(value=value)
            ttk.Entry(frame, textvariable=var, width=32).grid(row=i, column=1, pady=5, padx=5)
            fields[label] = var
        ttk.Label(frame, text="Status").grid(row=5, column=0, sticky="w", padx=5, pady=5)
        status = tk.StringVar(value=data["status"] if edit else "Aktif")
        ttk.Combobox(frame, textvariable=status, values=("Aktif","Nonaktif"),
                     state="readonly", width=29).grid(row=5, column=1, padx=5, pady=5)

        def simpan():
            from datetime import date as date_type
            try:
                tanggal = date_type.fromisoformat(fields["Tanggal Masuk (YYYY-MM-DD)"].get().strip())
                payload = {
                    "nik": fields["NIK"].get(), "nama": fields["Nama"].get(),
                    "jabatan": fields["Jabatan"].get(),
                    "gaji_pokok": fields["Gaji Pokok"].get(),
                    "tanggal_masuk": tanggal, "status": status.get()
                }
                if edit:
                    self.repo.ubah(data["id"], payload)
                else:
                    self.repo.tambah(payload)
                win.destroy()
                self.muat()
                messagebox.showinfo("Berhasil", "Data karyawan berhasil disimpan.")
            except Exception as exc:
                messagebox.showerror("Gagal Menyimpan", str(exc))

        ttk.Button(frame, text="Simpan", command=simpan).grid(row=6, column=1, sticky="e", pady=12)

    @aman("Gagal Menghapus Karyawan")
    def hapus(self):
        pilihan = self.tree.selection()
        if not pilihan:
            messagebox.showwarning("Pilih Data", "Pilih karyawan yang akan dihapus.")
            return
        nilai = self.tree.item(pilihan[0], "values")
        if messagebox.askyesno("Konfirmasi", f"Hapus karyawan {nilai[2]}?"):
            self.repo.hapus(int(nilai[0]))
            self.muat()
            messagebox.showinfo("Berhasil", "Data karyawan dihapus.")
