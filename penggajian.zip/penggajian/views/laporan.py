import csv
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import date
from decimal import Decimal
from repository import GajiRepository
from ui_common import tabel, aman
from model import rupiah


def aman_csv(nilai):
    teks = "" if nilai is None else str(nilai)
    if teks.startswith(("=", "+", "-", "@", "\t", "\r")):
        return "'" + teks
    return teks


class LaporanView(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=12)
        self.repo = GajiRepository()
        ttk.Label(self, text="Laporan Penggajian", font=("Segoe UI",18,"bold")).pack(anchor="w",pady=(0,10))
        bar = ttk.Frame(self)
        bar.pack(fill="x",pady=5)
        ttk.Label(bar,text="Periode (YYYY-MM, kosong = semua):").pack(side="left")
        self.periode = tk.StringVar(value=date.today().strftime("%Y-%m"))
        ttk.Entry(bar,textvariable=self.periode,width=12).pack(side="left",padx=6)
        ttk.Button(bar,text="Tampilkan",command=self.muat).pack(side="left")
        ttk.Button(bar,text="Ekspor CSV",command=self.ekspor).pack(side="right")
        self.tree = tabel(self,("id","periode","snapshot_nik","snapshot_nama","snapshot_jabatan",
            "snapshot_gaji_pokok","lembur_jam","upah_lembur","bruto","potongan","netto"),
            {"id":"ID","periode":"Periode","snapshot_nik":"NIK","snapshot_nama":"Nama",
             "snapshot_jabatan":"Jabatan","snapshot_gaji_pokok":"Gaji Pokok",
             "lembur_jam":"Lembur (jam)","upah_lembur":"Upah Lembur",
             "bruto":"Bruto","potongan":"Potongan","netto":"Netto"})
        bar2 = ttk.Frame(self)
        bar2.pack(fill="x",pady=8)
        ttk.Button(bar2,text="Simpan Slip Gaji (.txt)",command=self.slip).pack(side="left")
        self.rows = []
        self.muat()

    @aman("Gagal Memuat Laporan")
    def muat(self):
        self.rows = self.repo.riwayat(self.periode.get())
        self.tree.delete(*self.tree.get_children())
        for row in self.rows:
            self.tree.insert("", "end", values=(
                row["id"], row["periode"], row["snapshot_nik"], row["snapshot_nama"],
                row["snapshot_jabatan"], row["snapshot_gaji_pokok"], row["lembur_jam"],
                row["upah_lembur"], row["bruto"], row["potongan"], row["netto"]
            ))

    def baris_terpilih(self):
        pilihan = self.tree.selection()
        if not pilihan:
            raise ValueError("Pilih transaksi penggajian terlebih dahulu.")
        identitas = int(self.tree.item(pilihan[0],"values")[0])
        return next(row for row in self.rows if row["id"] == identitas)

    @aman("Gagal Membuat Slip")
    def slip(self):
        row = self.baris_terpilih()
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", filetypes=[("Text","*.txt")],
            initialfile=f'slip_{row["snapshot_nik"]}_{row["periode"]}.txt'
        )
        if not path:
            return
        isi = [
            "SLIP GAJI KARYAWAN", "=" * 36,
            f'Periode       : {row["periode"]}',
            f'NIK           : {row["snapshot_nik"]}',
            f'Nama          : {row["snapshot_nama"]}',
            f'Jabatan       : {row["snapshot_jabatan"]}',
            "-" * 36,
            f'Gaji Pokok    : {rupiah(row["snapshot_gaji_pokok"])}',
            f'Lembur        : {row["lembur_jam"]} jam',
            f'Upah Lembur   : {rupiah(row["upah_lembur"])}',
            f'Gaji Bruto    : {rupiah(row["bruto"])}',
            f'Potongan      : {rupiah(row["potongan"])}',
            f'Gaji Netto    : {rupiah(row["netto"])}',
            "-" * 36, f'Catatan       : {row["catatan"] or "-"}'
        ]
        with open(path,"w",encoding="utf-8") as file:
            file.write("\n".join(isi))
        messagebox.showinfo("Berhasil",f"Slip gaji disimpan:\n{path}")

    @aman("Gagal Ekspor CSV")
    def ekspor(self):
        if not self.rows:
            messagebox.showwarning("Data Kosong","Tidak ada data untuk diekspor.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",filetypes=[("CSV","*.csv")],
            initialfile="rekap_penggajian.csv"
        )
        if not path:
            return
        kolom = ["id","periode","snapshot_nik","snapshot_nama","snapshot_jabatan",
                 "snapshot_gaji_pokok","lembur_jam","upah_lembur","bruto","potongan","netto","catatan"]
        with open(path,"w",newline="",encoding="utf-8-sig") as file:
            writer = csv.writer(file)
            writer.writerow(kolom)
            for row in self.rows:
                writer.writerow([aman_csv(row.get(k)) for k in kolom])
        messagebox.showinfo("Berhasil",f"Rekap CSV disimpan:\n{path}")
